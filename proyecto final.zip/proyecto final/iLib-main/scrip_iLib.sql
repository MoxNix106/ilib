CREATE TABLE IF NOT EXISTS public.usuario_detalle
(
    id bigint generated always as identity primary key,
    nombre varchar(50) not null,
    ap_paterno varchar(50) not null,
    ap_materno varchar(50) not null,
    tipo varchar(20) not null
);
insert into public.usuario_detalle
    (nombre, ap_paterno, ap_materno, tipo)
values ('ViCTOR', ' ', 'DIAZ', 'ADMIN');

CREATE TABLE IF NOT EXISTS public.usuario
(
    id bigint generated always as identity primary key,
    usuario_detalle_id bigint not null references public.usuario_detalle(id),
    username varchar(20) not null,
    password varchar(256) not null,
    estado varchar(10) default 'INACTIVO'::character varying not null,
    role varchar(5) default 'USER'::character varying not null,
    cuenta_bloqueada boolean default false not null,
    fecha_creacion timestamp(6),
    fecha_modificacion timestamp(6),
    modificado_por varchar(50) default 'SYS_USER'::character varying not null
);
insert into public.usuario
    (usuario_detalle_id, username, password, estado, role, cuenta_bloqueada, fecha_creacion, fecha_modificacion, modificado_por)
values
    (1, 'victor', 'admin', 'ACTIVO', 'USER', false, '2024-10-24 14:27:13.718497', '2024-10-24 14:27:13.718497', 'SYS_USER');

CREATE TABLE IF NOT EXISTS public.cliente
(
    id bigint generated always as identity primary key,
    nombre varchar(50) not null,
    ap_paterno varchar(50) not null,
    ap_materno varchar(50) not null,
    email varchar(254) not null,
    telefono varchar(10) not null,
    fecha_creacion timestamp(6),
    fecha_modificacion timestamp(6),
    sanciones int DEFAULT 0,
    monto_sancion numeric(8,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.cliente 
ADD COLUMN codigo_cliente varchar(10) UNIQUE; 

CREATE OR REPLACE FUNCTION generar_codigo_cliente()
RETURNS TRIGGER AS $$
BEGIN
    NEW.codigo_cliente := 'LIB-' || LPAD(NEW.id::text, 5, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generar_codigo_cliente
BEFORE INSERT ON public.cliente
FOR EACH ROW
EXECUTE FUNCTION generar_codigo_cliente();

INSERT INTO public.cliente (nombre, ap_paterno, ap_materno, email, telefono, fecha_creacion, fecha_modificacion, sanciones, monto_sancion)
VALUES
('Juan', 'Pérez', 'Gómez', 'juan.perez@gmail.com', '5512345678', '2023-01-10 14:30:00', '2023-12-10 10:00:00', 1, 150.50),
('María', 'López', 'Hernández', 'maria.lopez@yahoo.com', '5523456789', '2023-03-15 08:45:00', NULL, 0, 0.00),
('Carlos', 'Ramírez', 'Martínez', 'carlos.ramirez@outlook.com', '5534567890', '2022-11-20 18:20:00', '2023-12-05 14:30:00', 2, 300.00),
('Ana', 'González', 'Ruiz', 'ana.gonzalez@hotmail.com', '5545678901', '2023-05-25 12:10:00', NULL, 0, 0.00),
('Luis', 'Fernández', 'Sánchez', 'luis.fernandez@gmail.com', '5556789012', '2023-07-30 09:00:00', '2023-12-12 16:50:00', 3, 450.75),
('Elena', 'Vargas', 'Sánchez', 'elena.vargas@mail.com', '5612345678', '2023-02-28 10:15:00', NULL, 0, 0.00),
('Ricardo', 'Morales', 'Torres', 'ricardo.morales@gmail.com', '5623456789', '2023-04-10 11:00:00', NULL, 0, 0.00),
('Sandra', 'Ramírez', 'Díaz', 'sandra.ramirez@gmail.com', '5634567890', '2023-06-12 15:25:00', '2023-12-15 10:10:00', 0, 0.00),
('David', 'Jiménez', 'García', 'david.jimenez@outlook.com', '5645678901', '2023-01-05 13:30:00', NULL, 0, 0.00),
('Patricia', 'González', 'Moreno', 'patricia.gonzalez@hotmail.com', '5656789012', '2023-08-19 09:45:00', '2023-12-10 08:00:00', 0, 0.00),
('José', 'Pérez', 'Luna', 'jose.perez@mail.com', '5667890123', '2023-02-15 14:20:00', NULL, 0, 0.00),
('Verónica', 'Hernández', 'Sosa', 'veronica.hernandez@gmail.com', '5678901234', '2023-09-01 16:30:00', '2023-12-08 12:00:00', 0, 0.00),
('Felipe', 'Castillo', 'Morales', 'felipe.castillo@yahoo.com', '5689012345', '2023-03-10 17:50:00', NULL, 0, 0.00),
('Lucía', 'Sánchez', 'Romero', 'lucia.sanchez@gmail.com', '5690123456', '2023-07-01 11:40:00', '2023-12-10 18:20:00', 0, 0.00),
('Mario', 'Torres', 'Vega', 'mario.torres@outlook.com', '5701234567', '2023-11-14 13:00:00', NULL, 0, 0.00),
('Raquel', 'Martínez', 'Núñez', 'raquel.martinez@gmail.com', '5712345678', '2023-05-30 10:10:00', '2023-12-02 14:40:00', 0, 0.00),
('Adrián', 'López', 'Salazar', 'adrian.lopez@hotmail.com', '5723456789', '2023-04-18 12:50:00', NULL, 0, 0.00),
('Carmen', 'García', 'Romero', 'carmen.garcia@yahoo.com', '5734567890', '2023-10-20 15:15:00', '2023-12-01 09:30:00', 0, 0.00),
('Antonio', 'Rodríguez', 'Vázquez', 'antonio.rodriguez@outlook.com', '5745678901', '2023-09-12 11:10:00', NULL, 0, 0.00),
('Isabel', 'Martín', 'Gutiérrez', 'isabel.martin@gmail.com', '5756789012', '2023-06-05 14:40:00', '2023-12-09 17:30:00', 0, 0.00);



CREATE TABLE IF NOT EXISTS public.libro
(
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    titulo varchar(300) not null,
	fecha_publicacion timestamp(6),
    autor varchar(50) not null,
    categoria varchar(50) not null,
	edicion varchar(50) not null,
    editorial varchar(50) not null,
    idioma varchar(50) not null,
    num_paginas int NOT NULL,
    descripcion varchar(300) not null,
    num_disponibles int NOT NULL
);
INSERT INTO public.libro (titulo, fecha_publicacion, autor, categoria, edicion, editorial, idioma, num_paginas, descripcion, num_disponibles) 
VALUES
('Cien años de soledad', '1967-05-30 00:00:00', 'Gabriel García Márquez', 'Novela', 'Primera', 'Editorial Sudamericana', 'Español', 471, 'Una obra maestra de la literatura latinoamericana.', 10),
('1984', '1949-06-08 00:00:00', 'George Orwell', 'Ciencia Ficción', 'Segunda', 'Secker & Warburg', 'Inglés', 328, 'Una distopía sobre un régimen totalitario.', 8),
('El señor de los anillos', '1954-07-29 00:00:00', 'J.R.R. Tolkien', 'Fantasía', 'Tercera', 'Allen & Unwin', 'Inglés', 1216, 'Una épica historia de la Tierra Media.', 5),
('Don Quijote de la Mancha', '1605-01-16 00:00:00', 'Miguel de Cervantes', 'Novela', 'Original', 'Francisco de Robles', 'Español', 863, 'Las aventuras de un hidalgo soñador.', 7),
('Orgullo y prejuicio', '1813-01-28 00:00:00', 'Jane Austen', 'Romance', 'Cuarta', 'T. Egerton, Whitehall', 'Inglés', 432, 'Una historia de amor y sociedad.', 6),
('Crimen y castigo', '1866-01-01 00:00:00', 'Fiódor Dostoyevski', 'Filosofía', 'Primera', 'El Mensajero Ruso', 'Ruso', 671, 'Un análisis psicológico de la culpa y la redención.', 9),
('El principito', '1943-04-06 00:00:00', 'Antoine de Saint-Exupéry', 'Fábula', 'Original', 'Reynal & Hitchcock', 'Francés', 96, 'Un viaje filosófico lleno de lecciones de vida.', 15),
('Harry Potter y la piedra filosofal', '1997-06-26 00:00:00', 'J.K. Rowling', 'Fantasía', 'Primera', 'Bloomsbury', 'Inglés', 223, 'La introducción al mundo mágico de Harry Potter.', 12),
('La metamorfosis', '1915-10-01 00:00:00', 'Franz Kafka', 'Novela', 'Primera', 'Kurt Wolff Verlag', 'Alemán', 100, 'La transformación de un hombre en insecto.', 10),
('El alquimista', '1988-01-01 00:00:00', 'Paulo Coelho', 'Filosofía', 'Primera', 'HarperTorch', 'Portugués', 208, 'Un viaje en busca de la realización personal.', 11),
('La sombra del viento', '2001-04-18', 'Carlos Ruiz Zafón', 'Misterio', 1, 'Planeta', 'Español', 576, 'Un viaje por los secretos de un libro maldito.', 10),
('El nombre del viento', '2007-03-27', 'Patrick Rothfuss', 'Fantasía', 1, 'DAW Books', 'Inglés', 662, 'La historia de Kvothe, un héroe y músico legendario.', 8),
('Los Juegos del Hambre', '2008-09-14', 'Suzanne Collins', 'Distopía', 1, 'Scholastic Press', 'Inglés', 374, 'Una competición mortal en un mundo distópico.', 12),
('Drácula', '1897-05-26', 'Bram Stoker', 'Terror', 1, 'Archibald Constable and Company', 'Inglés', 418, 'El clásico relato de vampiros.', 6),
('Fahrenheit 451', '1953-10-19', 'Ray Bradbury', 'Distopía', 1, 'Ballantine Books', 'Inglés', 194, 'Un mundo donde los libros están prohibidos.', 9),
('La Divina Comedia', '1320-01-01', 'Dante Alighieri', 'Épico', 1, 'Antiguo', 'Italiano', 798, 'Un viaje por el Infierno, el Purgatorio y el Paraíso.', 3),
('El guardián entre el centeno', '1951-07-16', 'J.D. Salinger', 'Drama', 1, 'Little, Brown and Company', 'Inglés', 277, 'La lucha de un joven con la hipocresía del mundo.', 7),
('Los miserables', '1862-04-03', 'Victor Hugo', 'Drama', 1, 'A. Lacroix, Verboeckhoven & Cie', 'Francés', 1463, 'Una obra épica sobre justicia y redención.', 4),
('Frankenstein', '1818-01-01', 'Mary Shelley', 'Terror', 1, 'Lackington, Hughes, Harding, Mavor & Jones', 'Inglés', 280, 'La creación de un monstruo y sus consecuencias.', 5),
('La Iliada', '750-01-01', 'Homero', 'Épico', 1, 'Antiguo', 'Griego', 700, 'El relato de la Guerra de Troya.', 4);

CREATE TABLE IF NOT EXISTS public.prestamo
(
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    usuario_id bigint NOT NULL references public.usuario(id),
    cliente_codigo varchar(10) NOT NULL references public.cliente(codigo_cliente),
    libro_id bigint NOT NULL references public.libro(id),
    fecha_prestamo timestamp(6),
    fecha_regreso timestamp(6)
);