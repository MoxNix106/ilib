/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interfaces;

import com.mycompany.models.UsuarioDetalle;
import java.util.List;

/**
 *
 * @author HP
 */
public interface DAOUsuarioDetalle {
    public void registrar(UsuarioDetalle usuarioDetalle) throws Exception;
    public void modificar(UsuarioDetalle usuarioDetalle) throws Exception;
    public void eliminar(Long id) throws Exception;
    public List<UsuarioDetalle> listar(String nombre) throws Exception;
    public UsuarioDetalle getUsuarioDetalleById(Long id) throws Exception;
}
