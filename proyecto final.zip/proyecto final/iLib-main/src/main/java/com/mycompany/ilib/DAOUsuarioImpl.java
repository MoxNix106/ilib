/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOUsuario;
import com.mycompany.models.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class DAOUsuarioImpl extends Database implements DAOUsuario {

    @Override
    public void registrar(Usuario usuario) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                "INSERT INTO usuario (usuario_detalle_id, username, password, estado, role, cuenta_bloqueada, fecha_creacion, modificado_por) VALUES (?, ?, ?, ?, ?, ?, ?, ?);"
            );
            st.setLong(1, usuario.getUsuarioDetalleId());
            st.setString(2, usuario.getUsername());
            st.setString(3, usuario.getPassword());
            st.setString(4, usuario.getEstado());
            st.setString(5, usuario.getRole());
            st.setBoolean(6, usuario.isCuentaBloqueada());
            st.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
            st.setString(8, usuario.getModificadoPor());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Usuario usuario) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                "UPDATE usuario SET usuario_detalle_id = ?, username = ?, password = ?, estado = ?, role = ?, cuenta_bloqueada = ?, fecha_modificacion = ?, modificado_por = ? WHERE id = ?;"
            );
            st.setLong(1, usuario.getUsuarioDetalleId());
            st.setString(2, usuario.getUsername());
            st.setString(3, usuario.getPassword());
            st.setString(4, usuario.getEstado());
            st.setString(5, usuario.getRole());
            st.setBoolean(6, usuario.isCuentaBloqueada());
            st.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
            st.setString(8, usuario.getModificadoPor());
            st.setLong(9, usuario.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(Long usuarioId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM usuario WHERE id = ?;");
            st.setLong(1, usuarioId);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Usuario> listar(String username) throws Exception {
        List<Usuario> lista = new ArrayList<>();
        try {
            this.Conectar();
            String query = username.isEmpty() ?
                "SELECT * FROM usuario;" :
                "SELECT * FROM usuario WHERE LOWER(username) LIKE LOWER(?);";
            PreparedStatement st = this.conexion.prepareStatement(query);
            if (!username.isEmpty()) {
                st.setString(1, "%" + username + "%");
            }

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getLong("id"));
                usuario.setUsuarioDetalleId(rs.getLong("usuario_detalle_id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setRole(rs.getString("role"));
                usuario.setCuentaBloqueada(rs.getBoolean("cuenta_bloqueada"));
                usuario.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                usuario.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
                usuario.setModificadoPor(rs.getString("modificado_por"));
                lista.add(usuario);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Usuario getUsuarioById(Long usuarioId) throws Exception {
        Usuario usuario = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuario WHERE id = ? LIMIT 1;");
            st.setLong(1, usuarioId);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getLong("id"));
                usuario.setUsuarioDetalleId(rs.getLong("usuario_detalle_id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setRole(rs.getString("role"));
                usuario.setCuentaBloqueada(rs.getBoolean("cuenta_bloqueada"));
                usuario.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                usuario.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
                usuario.setModificadoPor(rs.getString("modificado_por"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return usuario;
    }

    @Override
    public Usuario getUsuarioByUsername(String username) throws Exception {
        Usuario usuario = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuario WHERE username = ? LIMIT 1;");
            st.setString(1, username);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getLong("id"));
                usuario.setUsuarioDetalleId(rs.getLong("usuario_detalle_id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setRole(rs.getString("role"));
                usuario.setCuentaBloqueada(rs.getBoolean("cuenta_bloqueada"));
                usuario.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                usuario.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
                usuario.setModificadoPor(rs.getString("modificado_por"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return usuario;
    }    
}
