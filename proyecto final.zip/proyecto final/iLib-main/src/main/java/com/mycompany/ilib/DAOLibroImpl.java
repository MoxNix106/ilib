/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOLibro;
import com.mycompany.models.Libro;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class DAOLibroImpl extends Database implements DAOLibro {

    @Override
    public void registrar(Libro libro) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "INSERT INTO libro (titulo, fecha_publicacion, autor, categoria, edicion, editorial, idioma, num_paginas, descripcion, num_disponibles) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
            );
            st.setString(1, libro.getTitulo());
            st.setTimestamp(2, libro.getFechaPublicacion());
            st.setString(3, libro.getAutor());
            st.setString(4, libro.getCategoria());
            st.setString(5, libro.getEdicion());
            st.setString(6, libro.getEditorial());
            st.setString(7, libro.getIdioma());
            st.setInt(8, libro.getNumPaginas());
            st.setString(9, libro.getDescripcion());
            st.setInt(10, libro.getNumDisponibles());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Libro libro) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "UPDATE libro SET titulo = ?, fecha_publicacion = ?, autor = ?, categoria = ?, edicion = ?, editorial = ?, idioma = ?, num_paginas = ?, descripcion = ?, num_disponibles = ? WHERE id = ?"
            );
            st.setString(1, libro.getTitulo());
            st.setTimestamp(2, libro.getFechaPublicacion());
            st.setString(3, libro.getAutor());
            st.setString(4, libro.getCategoria());
            st.setString(5, libro.getEdicion());
            st.setString(6, libro.getEditorial());
            st.setString(7, libro.getIdioma());
            st.setInt(8, libro.getNumPaginas());
            st.setString(9, libro.getDescripcion());
            st.setInt(10, libro.getNumDisponibles());
            st.setLong(11, libro.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(Long libroId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM libro WHERE id = ?;");
            st.setLong(1, libroId);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Libro> listar(String titulo) throws Exception {
        List<Libro> lista = new ArrayList<>();
        try {
            this.Conectar();
            String query = titulo.isEmpty()
                    ? "SELECT * FROM libro;"
                    : "SELECT * FROM libro WHERE LOWER(titulo) LIKE LOWER(?);";
            PreparedStatement st = this.conexion.prepareStatement(query);
            if (!titulo.isEmpty()) {
                st.setString(1, "%" + titulo + "%");
            }

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Libro libro = new Libro();
                libro.setId(rs.getLong("id"));
                libro.setTitulo(rs.getString("titulo"));
                libro.setFechaPublicacion(rs.getTimestamp("fecha_publicacion"));
                libro.setAutor(rs.getString("autor"));
                libro.setCategoria(rs.getString("categoria"));
                libro.setEdicion(rs.getString("edicion"));
                libro.setEditorial(rs.getString("editorial"));
                libro.setIdioma(rs.getString("idioma"));
                libro.setNumPaginas(rs.getInt("num_paginas"));
                libro.setDescripcion(rs.getString("descripcion"));
                libro.setNumDisponibles(rs.getInt("num_disponibles"));
                lista.add(libro);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Libro getLibroById(Long libroId) throws Exception {
        Libro libro = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM libro WHERE id = ? LIMIT 1;");
            st.setLong(1, libroId);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                libro = new Libro();
                libro.setId(rs.getLong("id"));
                libro.setTitulo(rs.getString("titulo"));
                libro.setFechaPublicacion(rs.getTimestamp("fecha_publicacion"));
                libro.setAutor(rs.getString("autor"));
                libro.setCategoria(rs.getString("categoria"));
                libro.setEdicion(rs.getString("edicion"));
                libro.setEditorial(rs.getString("editorial"));
                libro.setIdioma(rs.getString("idioma"));
                libro.setNumPaginas(rs.getInt("num_paginas"));
                libro.setDescripcion(rs.getString("descripcion"));
                libro.setNumDisponibles(rs.getInt("num_disponibles"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return libro;
    }

    @Override
    public Long getIdByTitle(String titulo) {
        Long libroId = null;
        try {
            this.Conectar();
            try (PreparedStatement st = this.conexion.prepareStatement("SELECT id FROM libro WHERE titulo = ? LIMIT 1;")) {
                st.setString(1, titulo);

                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    libroId = rs.getLong("id");
                }
                rs.close();
            }
        } catch (Exception e) {
            try {
                throw e;
            } catch (Exception ex) {
                Logger.getLogger(DAOLibroImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        } finally {
            try {
                this.Cerrar();
            } catch (SQLException ex) {
                Logger.getLogger(DAOLibroImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return libroId;
    }

    @Override
    public void incrementarInventario(Long libroId) {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "UPDATE libro SET num_disponibles = num_disponibles + 1 WHERE id = ?;"
            );
            st.setLong(1, libroId);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            try {
                throw e;
            } catch (Exception ex) {
                Logger.getLogger(DAOLibroImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        } finally {
            try {
                this.Cerrar();
            } catch (SQLException ex) {
                Logger.getLogger(DAOLibroImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
