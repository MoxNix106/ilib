/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interfaces;

import com.mycompany.models.Libro;
import java.util.List;

/**
 *
 * @author HP
 */
public interface DAOLibro {
    public void registrar(Libro libro) throws Exception;
    public void modificar(Libro libro) throws Exception;
    public void eliminar(Long libroId) throws Exception;
    public List<Libro> listar(String titulo) throws Exception;
    public Libro getLibroById(Long libroId) throws Exception;

    public Long getIdByTitle(String titulo);

    public void incrementarInventario(Long libroId);
}
