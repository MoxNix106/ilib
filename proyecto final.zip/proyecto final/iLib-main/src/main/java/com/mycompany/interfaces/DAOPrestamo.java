/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interfaces;

import com.mycompany.models.Prestamo;
import java.util.List;

/**
 *
 * @author HP
 */
public interface DAOPrestamo {
    public void registrar(Prestamo prestamo) throws Exception;
    public void modificar(Prestamo prestamo) throws Exception;
    public void eliminar(Long prestamoId) throws Exception;
    public List<Prestamo> listar(Long clienteId) throws Exception;
    public Prestamo getPrestamoById(Long prestamoId) throws Exception;
}
