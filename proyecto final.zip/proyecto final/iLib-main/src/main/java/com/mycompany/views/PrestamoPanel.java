package com.mycompany.views;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.mycompany.ilib.DAOLibroImpl;
import com.mycompany.ilib.DAOPrestamoImpl;
import com.mycompany.ilib.DAOUsuarioImpl;
import com.mycompany.interfaces.DAOLibro;
import com.mycompany.interfaces.DAOPrestamo;
import com.mycompany.interfaces.DAOUsuario;
import com.mycompany.models.Usuario;
import java.awt.Color;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import javax.swing.table.DefaultTableModel;

public class PrestamoPanel extends javax.swing.JPanel {

    private String usuarioLogueado;
    private Long usuarioId;

    public PrestamoPanel(String codigo, String nombre, String apellido, String usuarioLogueado) {
        this.usuarioLogueado = usuarioLogueado;
        initComponents();
        labelInfoCliente.setText(codigo + " - " + nombre + " " + apellido);

        try {
            DAOUsuario daoUsuario = new DAOUsuarioImpl();
            Usuario usuario = daoUsuario.getUsuarioByUsername(usuarioLogueado);
            if (usuario != null) {
                this.usuarioId = usuario.getId(); // Guardar el ID del usuario logueado
            } else {
                JOptionPane.showMessageDialog(this, "Usuario no encontrado.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al obtener el usuario logueado: " + e.getMessage());
        }

        // Mostrar el usuario logueado en el JPanel
        JLabel labelUsuario = new JLabel("Usuario logueado: " + usuarioLogueado);
        labelUsuario.setForeground(Color.BLACK);
        bg.add(labelUsuario); // Agregar el label al panel principal 'bg'
    }

    // Método para generar la factura y enviarla
    // Método para generar un PDF con los detalles del préstamo
    private String generarPDFPrestamo(String usuario, String libro) {
        String rutaCarpeta = "C:\\Semestre 5\\Topicos\\PDF Enviados"; // Ruta para guardar los PDFs
        String fileName = rutaCarpeta + "\\Prestamo_" + usuario + "_" + libro + ".pdf";

        // Crear la carpeta si no existe
        File carpeta = new File(rutaCarpeta);
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

        // Generar el PDF
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            // Título
            Paragraph title = new Paragraph("Detalles del Préstamo", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18));
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph(" "));

            // Información del préstamo
            document.add(new Paragraph("Usuario: " + usuario));
            document.add(new Paragraph("Libro: " + libro));
            document.add(new Paragraph("Fecha del préstamo: " + java.time.LocalDate.now()));
            document.add(new Paragraph(" "));

            document.close();
            return fileName;

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al generar el PDF: " + e.getMessage());
            return null;
        }
    }

    // Método para enviar un correo con un archivo PDF adjunto//////////////////////////////////////////////////////////
    private void enviarCorreoConAdjunto(String emailDestino, String filePath) {
        final String remitente = ""; // Cambia por tu correo
        final String password = ""; // Cambia por tu contraseña o app password

        // Configuración del servidor SMTP
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Crear sesión de correo
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, password);
            }
        });

        try {
            // Crear mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailDestino));
            message.setSubject("Detalles del Préstamo");

            // Cuerpo del mensaje
            MimeBodyPart mensajeTexto = new MimeBodyPart();
            mensajeTexto.setText("Adjunto encontrará los detalles del préstamo en formato PDF.");

            // Adjuntar el archivo PDF
            MimeBodyPart adjunto = new MimeBodyPart();
            DataSource source = new FileDataSource(filePath);
            adjunto.setDataHandler(new DataHandler(source));
            adjunto.setFileName(new File(filePath).getName());

            // Combinar partes
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mensajeTexto);
            multipart.addBodyPart(adjunto);

            message.setContent(multipart);

            // Enviar el correo
            Transport.send(message);
            JOptionPane.showMessageDialog(this, "Correo enviado exitosamente a: " + emailDestino);

        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al enviar el correo: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        button = new javax.swing.JButton();
        labelClienteSeleccionado = new javax.swing.JLabel();
        labelInfoCliente = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bookSearch = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        bg.setBackground(new java.awt.Color(255, 255, 255));

        button.setBackground(new java.awt.Color(18, 90, 173));
        button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        button.setForeground(new java.awt.Color(255, 255, 255));
        button.setText("Prestar");
        button.setBorderPainted(false);
        button.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActionPerformed(evt);
            }
        });

        labelClienteSeleccionado.setText("Cliente:");

        labelInfoCliente.setBackground(new java.awt.Color(64, 73, 75));
        labelInfoCliente.setToolTipText("");

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Título", "Fecha de Pub.", "Autor", "Categoría", "Edición", "Editorial", "Idioma", "Paginas", "Descripcion ", "Disponibles"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTable1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        searchButton.setBackground(new java.awt.Color(18, 90, 173));
        searchButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchButton.setForeground(new java.awt.Color(255, 255, 255));
        searchButton.setText("Buscar");
        searchButton.setBorderPainted(false);
        searchButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 811, Short.MAX_VALUE)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(labelClienteSeleccionado)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(labelInfoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(bookSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(searchButton)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(350, 350, 350)
                .addComponent(button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(labelClienteSeleccionado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labelInfoCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(35, 35, 35)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bookSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
                .addGap(51, 51, 51)
                .addComponent(button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonActionPerformed
        // Obtener el cliente y libro seleccionados de la interfaz
        String clienteInfo = labelInfoCliente.getText(); // Ejemplo: "123 - Juan Pérez"
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow != -1 && clienteInfo != null && !clienteInfo.isEmpty()) {
            try {
                // Obtener código del cliente
                String[] clienteData = clienteInfo.split(" - ");
                String clienteCodigo = clienteData[0];

                // Obtener datos del libro seleccionado
                String libroTitulo = (String) jTable1.getValueAt(selectedRow, 0);

                // Crear instancia de DAO para obtener el ID del libro
                DAOLibro daoLibro = new DAOLibroImpl();
                Long libroId = daoLibro.getIdByTitle(libroTitulo);

                // Crear el objeto Prestamo (entidad)
                com.mycompany.models.Prestamo prestamo = new com.mycompany.models.Prestamo();
                prestamo.setUsuarioId(usuarioId);
                prestamo.setClienteCodigo(clienteCodigo);
                prestamo.setLibroId(libroId);
                prestamo.setFechaPrestamo(new java.sql.Timestamp(System.currentTimeMillis()));
                prestamo.setFechaRegreso(null);

                // Registrar el préstamo en la base de datos
                DAOPrestamo daoPrestamo = new DAOPrestamoImpl();
                daoPrestamo.registrar(prestamo);

                // Actualizar la tabla de libros para reflejar el cambio en el inventario
                ((DefaultTableModel) jTable1.getModel()).setRowCount(0);
                daoLibro.listar("").forEach((libro) -> {
                    ((DefaultTableModel) jTable1.getModel()).addRow(new Object[]{
                        libro.getTitulo(),
                        libro.getFechaPublicacion(),
                        libro.getAutor(),
                        libro.getCategoria(),
                        libro.getEdicion(),
                        libro.getEditorial(),
                        libro.getIdioma(),
                        libro.getNumPaginas(),
                        libro.getDescripcion(),
                        libro.getNumDisponibles()
                    });
                });

                // Generar el PDF del préstamo
                String pdfPath = generarPDFPrestamo(usuarioLogueado, libroTitulo);

                // Enviar correo con el PDF adjunto
                String emailUsuario = ""; // Aquí debes obtener el correo real del usuario
                enviarCorreoConAdjunto(emailUsuario, pdfPath);

                JOptionPane.showMessageDialog(this, "Préstamo registrado y correo enviado exitosamente.");

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al registrar el préstamo: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un cliente y un libro.");
        }
    }//GEN-LAST:event_buttonActionPerformed

    private void jTable1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MousePressed

    }//GEN-LAST:event_jTable1MousePressed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        try {
            DAOLibro dao = new DAOLibroImpl();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            dao.listar(bookSearch.getText()).forEach((libro) -> {
                model.addRow(new Object[]{
                    //ibro.getId(),
                    libro.getTitulo(),
                    libro.getFechaPublicacion(),
                    libro.getAutor(),
                    libro.getCategoria(),
                    libro.getEdicion(),
                    libro.getEditorial(),
                    libro.getIdioma(),
                    libro.getNumPaginas(),
                    libro.getDescripcion(),
                    libro.getNumDisponibles()
                });
            });
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_searchButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private javax.swing.JTextField bookSearch;
    private javax.swing.JButton button;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelClienteSeleccionado;
    private javax.swing.JLabel labelInfoCliente;
    private javax.swing.JButton searchButton;
    // End of variables declaration//GEN-END:variables
}
