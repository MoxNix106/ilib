/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.models;

import java.sql.Timestamp;

/**
 *
 * @author HP
 */
public class Prestamo {
    private Long id;
    private Long usuarioId;
    private String clienteCodigo; // Cambiado de Long a String
    private Long libroId;
    private Timestamp fechaPrestamo;
    private Timestamp fechaRegreso;

    // Constructor vacío
    public Prestamo() {
    }

    // Constructor con ID
    public Prestamo(Long id) {
        this.id = id;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getClienteCodigo() {
        return clienteCodigo;
    }

    public void setClienteCodigo(String clienteCodigo) {
        this.clienteCodigo = clienteCodigo;
    }

    public Long getLibroId() {
        return libroId;
    }

    public void setLibroId(Long libroId) {
        this.libroId = libroId;
    }

    public Timestamp getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Timestamp fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public Timestamp getFechaRegreso() {
        return fechaRegreso;
    }

    public void setFechaRegreso(Timestamp fechaRegreso) {
        this.fechaRegreso = fechaRegreso;
    }
}
