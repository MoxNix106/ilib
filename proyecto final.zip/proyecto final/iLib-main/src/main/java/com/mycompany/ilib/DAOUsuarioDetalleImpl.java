/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOUsuarioDetalle;
import com.mycompany.models.UsuarioDetalle;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class DAOUsuarioDetalleImpl extends Database implements DAOUsuarioDetalle {

    @Override
    public void registrar(UsuarioDetalle usuarioDetalle) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "INSERT INTO usuario_detalle (nombre, ap_paterno, ap_materno, tipo) VALUES (?, ?, ?, ?);"
            );
            st.setString(1, usuarioDetalle.getNombre());
            st.setString(2, usuarioDetalle.getApPaterno());
            st.setString(3, usuarioDetalle.getApMaterno());
            st.setString(4, usuarioDetalle.getTipo());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(UsuarioDetalle usuarioDetalle) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "UPDATE usuario_detalle SET nombre = ?, ap_paterno = ?, ap_materno = ?, tipo = ? WHERE id = ?;"
            );
            st.setString(1, usuarioDetalle.getNombre());
            st.setString(2, usuarioDetalle.getApPaterno());
            st.setString(3, usuarioDetalle.getApMaterno());
            st.setString(4, usuarioDetalle.getTipo());
            st.setLong(5, usuarioDetalle.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(Long id) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "DELETE FROM usuario_detalle WHERE id = ?;"
            );
            st.setLong(1, id);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<UsuarioDetalle> listar(String nombre) throws Exception {
        List<UsuarioDetalle> lista = new ArrayList<>();
        try {
            this.Conectar();
            String query = nombre.isEmpty()
                    ? "SELECT * FROM usuario_detalle;"
                    : "SELECT * FROM usuario_detalle WHERE LOWER(nombre) LIKE LOWER(?);";
            PreparedStatement st = this.conexion.prepareStatement(query);
            if (!nombre.isEmpty()) {
                st.setString(1, "%" + nombre + "%");
            }

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                UsuarioDetalle usuarioDetalle = new UsuarioDetalle();
                usuarioDetalle.setId(rs.getLong("id"));
                usuarioDetalle.setNombre(rs.getString("nombre"));
                usuarioDetalle.setApPaterno(rs.getString("ap_paterno"));
                usuarioDetalle.setApMaterno(rs.getString("ap_materno"));
                usuarioDetalle.setTipo(rs.getString("tipo"));
                lista.add(usuarioDetalle);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public UsuarioDetalle getUsuarioDetalleById(Long id) throws Exception {
        UsuarioDetalle usuarioDetalle = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "SELECT * FROM usuario_detalle WHERE id = ? LIMIT 1;"
            );
            st.setLong(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                usuarioDetalle = new UsuarioDetalle();
                usuarioDetalle.setId(rs.getLong("id"));
                usuarioDetalle.setNombre(rs.getString("nombre"));
                usuarioDetalle.setApPaterno(rs.getString("ap_paterno"));
                usuarioDetalle.setApMaterno(rs.getString("ap_materno"));
                usuarioDetalle.setTipo(rs.getString("tipo"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return usuarioDetalle;
    }

}
