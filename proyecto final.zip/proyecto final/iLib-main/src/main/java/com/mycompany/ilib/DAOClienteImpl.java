/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOCliente;
import com.mycompany.models.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class DAOClienteImpl extends Database implements DAOCliente {

    @Override
    public void registrar(Cliente cliente) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                "INSERT INTO cliente (nombre, ap_paterno, ap_materno, email, telefono, fecha_creacion, sanciones, monto_sancion) VALUES (?, ?, ?, ?, ?, ?, ?, ?);"
            );
            st.setString(1, cliente.getNombre());
            st.setString(2, cliente.getApPaterno());
            st.setString(3, cliente.getApMaterno());
            st.setString(4, cliente.getEmail());
            st.setString(5, cliente.getTelefono());
            st.setTimestamp(6, new Timestamp(System.currentTimeMillis())); // Fecha de creación actual
            st.setInt(7, cliente.getSanciones());
            st.setDouble(8, cliente.getMontoSancion());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Cliente cliente) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                "UPDATE cliente SET nombre = ?, ap_paterno = ?, ap_materno = ?, email = ?, telefono = ?, fecha_modificacion = ?, sanciones = ?, monto_sancion = ? WHERE id = ?"
            );
            st.setString(1, cliente.getNombre());
            st.setString(2, cliente.getApPaterno());
            st.setString(3, cliente.getApMaterno());
            st.setString(4, cliente.getEmail());
            st.setString(5, cliente.getTelefono());
            st.setTimestamp(6, new Timestamp(System.currentTimeMillis())); // Fecha de modificación actual
            st.setInt(7, cliente.getSanciones());
            st.setDouble(8, cliente.getMontoSancion());
            st.setLong(9, cliente.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void sancionar(Cliente cliente) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                "UPDATE cliente SET sanciones = ?, monto_sancion = ? WHERE id = ?"
            );
            st.setInt(1, cliente.getSanciones());
            st.setDouble(2, cliente.getMontoSancion());
            st.setLong(3, cliente.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(Long clienteId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM cliente WHERE id = ?;");
            st.setLong(1, clienteId);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Cliente> listar(String nombre) throws Exception {
        List<Cliente> lista = new ArrayList<>();
        try {
            this.Conectar();
            String query = nombre.isEmpty() ? 
                "SELECT * FROM cliente;"
                : "SELECT * FROM cliente WHERE LOWER(nombre) LIKE LOWER(?);";
            PreparedStatement st = this.conexion.prepareStatement(query);
            if (!nombre.isEmpty()) {
                st.setString(1, "%" + nombre + "%");
            }

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getLong("id"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApPaterno(rs.getString("ap_paterno"));
                cliente.setApMaterno(rs.getString("ap_materno"));
                cliente.setEmail(rs.getString("email"));
                cliente.setTelefono(rs.getString("telefono"));
                cliente.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                cliente.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
                cliente.setSanciones(rs.getInt("sanciones"));
                cliente.setMontoSancion(rs.getDouble("monto_sancion"));
                cliente.setCodigoCliente(rs.getString("codigo_cliente"));
                lista.add(cliente);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Cliente getClienteById(Long clienteId) throws Exception {
        Cliente cliente = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM cliente WHERE id = ? LIMIT 1;");
            st.setLong(1, clienteId);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setId(rs.getLong("id"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApPaterno(rs.getString("ap_paterno"));
                cliente.setApMaterno(rs.getString("ap_materno"));
                cliente.setEmail(rs.getString("email"));
                cliente.setTelefono(rs.getString("telefono"));
                cliente.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                cliente.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
                cliente.setSanciones(rs.getInt("sanciones"));
                cliente.setMontoSancion(rs.getDouble("monto_sancion"));
                cliente.setCodigoCliente(rs.getString("codigo_cliente"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return cliente;
    }
    @Override
public Cliente getClienteByCodigo(String codigoCliente) throws Exception {
    Cliente cliente = null;
    try {
        this.Conectar();
        PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM cliente WHERE codigo_cliente = ? LIMIT 1;");
        st.setString(1, codigoCliente);

        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            cliente = new Cliente();
            cliente.setId(rs.getLong("id"));
            cliente.setNombre(rs.getString("nombre"));
            cliente.setApPaterno(rs.getString("ap_paterno"));
            cliente.setApMaterno(rs.getString("ap_materno"));
            cliente.setEmail(rs.getString("email"));
            cliente.setTelefono(rs.getString("telefono"));
            cliente.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
            cliente.setFechaModificacion(rs.getTimestamp("fecha_modificacion"));
            cliente.setSanciones(rs.getInt("sanciones"));
            cliente.setMontoSancion(rs.getDouble("monto_sancion"));
            cliente.setCodigoCliente(rs.getString("codigo_cliente"));
        }
        rs.close();
        st.close();
    } catch (Exception e) {
        throw e;
    } finally {
        this.Cerrar();
    }
    return cliente;
}

    /**
     *
     * @param codigoCliente
     * @return
     */
    //@Override
    //public Cliente getClienteByCodigo(String codigoCliente) {
      //  throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}
   
}


