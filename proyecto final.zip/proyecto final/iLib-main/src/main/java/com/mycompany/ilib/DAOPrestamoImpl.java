/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOPrestamo;
import com.mycompany.models.Prestamo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class DAOPrestamoImpl extends Database implements DAOPrestamo {

    @Override
    public void registrar(Prestamo prestamo) throws Exception {
        try {
            this.Conectar();
            // Registrar el préstamo
            PreparedStatement st = this.conexion.prepareStatement(
                    "INSERT INTO prestamo (usuario_id, cliente_codigo, libro_id, fecha_prestamo, fecha_regreso) VALUES (?, ?, ?, ?, ?);"
            );
            st.setLong(1, prestamo.getUsuarioId());
            st.setString(2, prestamo.getClienteCodigo());
            st.setLong(3, prestamo.getLibroId());
            st.setTimestamp(4, prestamo.getFechaPrestamo());
            st.setTimestamp(5, prestamo.getFechaRegreso());

            st.executeUpdate();
            st.close();

            // Descontar un libro del inventario
            PreparedStatement stUpdate = this.conexion.prepareStatement(
                    "UPDATE libro SET num_disponibles = num_disponibles - 1 WHERE id = ? AND num_disponibles > 0;"
            );
            stUpdate.setLong(1, prestamo.getLibroId());
            stUpdate.executeUpdate();
            stUpdate.close();

        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Prestamo prestamo) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(
                    "UPDATE prestamo SET usuario_id = ?, cliente_codigo = ?, libro_id = ?, fecha_prestamo = ?, fecha_regreso = ? WHERE id = ?;"
            );
            st.setLong(1, prestamo.getUsuarioId());
            st.setString(2, prestamo.getClienteCodigo());
            st.setLong(3, prestamo.getLibroId());
            st.setTimestamp(4, prestamo.getFechaPrestamo());
            st.setTimestamp(5, prestamo.getFechaRegreso());
            st.setLong(6, prestamo.getId());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(Long prestamoId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM prestamo WHERE id = ?;");
            st.setLong(1, prestamoId);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Prestamo> listar(Long clienteId) throws Exception {
        List<Prestamo> lista = new ArrayList<>();
        try {
            this.Conectar();
            String query = clienteId == null
                    ? "SELECT * FROM prestamo;"
                    : "SELECT * FROM prestamo WHERE cliente_codigo = ?;";
            PreparedStatement st = this.conexion.prepareStatement(query);
            if (clienteId != null) {
                st.setString(1, clienteId.toString());
            }

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Prestamo prestamo = new Prestamo();
                prestamo.setId(rs.getLong("id"));
                prestamo.setUsuarioId(rs.getLong("usuario_id"));
                prestamo.setClienteCodigo(rs.getString("cliente_codigo"));
                prestamo.setLibroId(rs.getLong("libro_id"));
                prestamo.setFechaPrestamo(rs.getTimestamp("fecha_prestamo"));
                prestamo.setFechaRegreso(rs.getTimestamp("fecha_regreso"));
                lista.add(prestamo);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;

    }

    @Override
    public Prestamo getPrestamoById(Long prestamoId) throws Exception {
        Prestamo prestamo = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM prestamo WHERE id = ? LIMIT 1;");
            st.setLong(1, prestamoId);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                prestamo = new Prestamo();
                prestamo.setId(rs.getLong("id"));
                prestamo.setUsuarioId(rs.getLong("usuario_id"));
                prestamo.setClienteCodigo(rs.getString("cliente_codigo"));
                prestamo.setLibroId(rs.getLong("libro_id"));
                prestamo.setFechaPrestamo(rs.getTimestamp("fecha_prestamo"));
                prestamo.setFechaRegreso(rs.getTimestamp("fecha_regreso"));
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return prestamo;
    }
}
